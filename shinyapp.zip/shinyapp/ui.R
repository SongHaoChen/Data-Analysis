library(shiny)
library(shinyjs)
library(shinydashboard)
library(shinyWidgets)
library(ggplot2)
library(reshape2)
library(ggradar)
library(pROC)
library(psych)
library(cluster)
library(fpc)
library(wordcloud2)

# view module
widget_ui <- function(id, panel_id, x_breaks, y_breaks, theme, grid, title){
  wellPanel(id = panel_id,
            textInput(inputId = x_breaks, label = '请设置刻度线在x轴出现的位置(例：10 15 20)', value = '默认'),
            textInput(inputId = y_breaks, label = '请设置刻度线在y轴出现的位置(例：10 15 20)', value = '默认'),
            selectInput(inputId = theme, 
                        label = '请选择主题类型',
                        choice = c('theme_bw', 'theme_light', 'theme_dark')),
            selectInput(inputId = grid, 
                        label = '请选择隐藏网格线类型',
                        choice = c('无', '隐藏纵轴网格线', '隐藏横轴网格线', '隐藏所有网格线')),
            textInput(inputId = title, label = '请输入标题'),
            )
  
}



# Define UI for application that draws a histogram
fluidPage(
  
  #使用includeCSS函数加载CSS
  includeCSS("style.css"),
  # Application title
  headerPanel("Data Analysis"),
  useShinyjs(),
  fluidRow(

    #最左侧；column(x,……)  x表示宽度
    column(3,
      p('\b'),
      titlePanel("读入数据"),
      wellPanel(

      # 读取数据集file1
      fileInput("file1", "Choose CSV File",
                multiple = FALSE,
                accept = c("text/csv",
                           "text/comma-separated-values,text/plain",
                           ".csv")),
      ),
      p('\b'),
      titlePanel("选择功能"),
      tabsetPanel(
        tabPanel("数据处理",uiOutput("tab_ds")),
        tabPanel("可视化",uiOutput("tab_view")),
        tabPanel("方法",uiOutput("tab_method")),
        id = 'tabset'
        ),
      p('\b'),
      titlePanel("保存数据"),
      wellPanel(
        textInput(inputId='savename',label='输入文件名(不包含".csv")'),
        actionButton("save", "保存"),
        wellPanel(id = 'savesuccess',
          textOutput("savetext")
        ),
      ),
      p('\b'),
      actionButton(inputId = "openUserManual",label="打开用户使用手册",width="100%",class = "btn btn-danger btn"),   
      p('\b'),
      actionButton(inputId = "openMulu",label="打开工作文件夹",width="100%",class = "btn btn-danger btn"),  
    
    ),
    
  
    #界面中间
    column(9,
    mainPanel(Id = 'main',
              
      wellPanel(id = 'ds_title_1',
          tableOutput("ds_title_1_showname"),
          tableOutput("ds_title_1_showdata"),
      ),
      
      wellPanel(id = 'ds_title_2',
          uiOutput("ds_title_2_select"),
          textInput(inputId = 'ds_title_2_newname', label = '更名为'),
          actionButton("ds_title_2_applynewname", "应用")
      ),
      wellPanel(id = 'ds_title_3',
          "警告：无法将两列命名为同一名称"        
      ),
      
      wellPanel(id = 'ds_coding_1',
                tableOutput("ds_coding_1_showname"),
                tableOutput("ds_coding_1_out")),
      wellPanel( id = 'ds_coding_2',
                 uiOutput("ds_coding_2_select"),
                 selectInput(inputId = 'ds_coding_2_method',
                             label = '选择一种分组的方法',
                             choices = c('2groups_median', '2groups_mean', '3groups_median','4groups_median')),
                 actionButton("ds_coding_2_applynewname", "应用")
                 
      ),
      
      wellPanel(id = 'ds_repeating_1',
          actionButton("ds_repeating_1_applydelete","删除重复值"),
          actionButton("ds_repeating_1_cancel","撤回", icon("undo-alt")),
          textOutput("ds_repeating_1_describe"),
          tableOutput("ds_repeating_1_show")          
      ),
    
      wellPanel(id = 'ds_exceptonValues_1',
          uiOutput('ds_exceptonValues_1_select'),    
          wellPanel(
              fluidRow(
                  column(3,
                       awesomeCheckbox(
                           inputId = "ds_exceptonValues_1_lack",
                           label = '缺失数字', 
                           value = FALSE,
                           status = "danger"
                       ),
                   ),
              ),
          ),
          wellPanel(
            fluidRow(
              column(3,
                     awesomeCheckbox(
                       inputId = "ds_exceptonValues_1_greater",
                       label = '数字>', 
                       value = FALSE,
                       status = "danger"
                     ),
              ),
              column(3,
                    numericInput(inputId = "ds_exceptonValues_1_greater_number",
                                 label = NULL,
                                 width = '100%',
                                 value = NULL
                    ),
              ),
            ),
          ),
          wellPanel(
            fluidRow(
              column(3,
                     awesomeCheckbox(
                       inputId = "ds_exceptonValues_1_less",
                       label = '数字<', 
                       value = FALSE,
                       status = "danger"
                     ),
              ),
              column(3,
                     numericInput(inputId = "ds_exceptonValues_1_less_number",
                                  label = NULL,
                                  width = '100%',
                                  value = NULL
                     ),
              ),
            ),
          ),         
          wellPanel(
            fluidRow(
              column(6,
                     awesomeCheckbox(
                       inputId = "ds_exceptonValues_1_offcenter",
                       label = '数字偏离中心 > k * 标准差; k=', 
                       value = FALSE,
                       status = "danger"
                     ),
              ),
              column(3,
                     numericInput(inputId = "ds_exceptonValues_1_offcenter_number",
                                  label = NULL,
                                  width = '100%',
                                  value = 3
                     ),
              ),
            ),
          ),           
          pickerInput(
            inputId = "ds_exceptonValues_1_2",
            label = "选择方案", 
            choices = c('NA', '平均值', '中位数', '众数', '0'),
            options = list(
              style = "btn-primary")
          ),
          actionButton(inputId = "ds_exceptonValues_1_apply", label = "确认更改",width = '100%',class = "btn btn-danger btn"),
      ),
      
      wellPanel(id = 'ds_variable_1',
                tableOutput("ds_variable_1_showname"),
                tableOutput("ds_variable_1_out")),
      wellPanel( id = 'ds_variable_2',
                 uiOutput("ds_variable_2_select"),
                 selectInput(inputId = 'ds_variable_2_method',
                             label = '选择一种生成方式',
                             choices = c('标准化(S)', '中心化(C)', '归一化(MMS)','均值化(MC)','逆向化(NMMS)','区间化(Interval)','初值化(Init)','求和归一化(SN)','平方和归一化(SSN)',
                                         '倒数(cb)','自然对数(Ln)','c10底对数(Log)','平方(Sq)','立方(Cube)','相反数(Op)')),
                 actionButton("ds_variable_2_applynewname", "应用"),
                 actionButton('ds_variable_2_hlevel', '高级公式')
      ),
      wellPanel(id = 'ds_variable_3',
                textInput(inputId = 'ds_variable_3_text', label = '输入公式(例：var1^2+2*var2)'),
                uiOutput("ds_variable_select_var1"),
                uiOutput("ds_variable_select_var2"),
                actionButton('ds_variable_3_applynewname', '应用'),
      ),
    
      wellPanel(id = 'method_discribe_1',
                uiOutput("method_discribe_1_select"),
                actionButton(inputId = "method_describe_1_apply", label = "分析",width = '100%',class = "btn btn-warning btn")),
      wellPanel(id = 'method_discribe_2',
                tableOutput("method_discribe_2_result")),
      
      wellPanel(id = 'method_cor_1',
                uiOutput("method_cor_1_select"),
                actionButton(inputId = "method_cor_1_apply", label = "分析",width = '100%',class = "btn btn-warning btn")),
      
      wellPanel(id = 'method_cor_2',
                tableOutput("method_cor_2_matrix")
                ),
      
      wellPanel(id = 'method_cor_3',
                pickerInput(
                  inputId = "method_cor_3_high",
                  label = "相关度高时的颜色", 
                  choices = c("black","white","green","pink","yellow","red","blue","orange"),
                  options = list(
                    style = "btn-primary")),
                pickerInput(
                  inputId = "method_cor_3_low",
                  label = "相关度低时的颜色", 
                  choices = c("white","black","green","pink","yellow","red","blue","orange"),
                  options = list(
                    style = "btn-primary")),
                plotOutput("method_cor_3_pic"),),
      
      wellPanel(id = 'method_regression_1',
                uiOutput('method_regression_1_selecty'),
                uiOutput('method_regression_1_selectx'),
                actionButton(inputId = "method_regression_1_apply", label = "分析",width = '100%',class = "btn btn-warning btn"),),
      wellPanel(id = 'method_regression_2',
                verbatimTextOutput("method_regression_2_result"),
                plotOutput('method_regression_2_picture')
                ),
      
      wellPanel(id = 'view_scatter_1',
                uiOutput("view_scatter_1_selectx"),
                uiOutput("view_scatter_1_selecty"),
                uiOutput("view_scatter_1_selectg"),
                actionButton("view_scatter_1_applynewname", "应用"),
      ),
      wellPanel( id = 'view_scatter_2',
                 plotOutput('view_scatter_2_plot'),
                 actionButton('view_scatter_2_control', label = '调节图形的整体外观')
      ),
      widget_ui(view_scatter, 'view_scatter_3', 'scatter_x_breaks', 'scatter_y_breaks', 'scatter_theme', 'scatter_grid', 'scatter_title'),
      wellPanel(id = 'view_hist_1',
                uiOutput("view_hist_1_selectx"),
                uiOutput("view_hist_1_selectg"),
                selectInput(inputId = 'view_hist_1_type',
                            label = '选择作图类型',
                            choices = c('频数分布直方图','频率分布直方图')),
                selectInput(inputId = 'view_hist_1_line',
                            label = '选择是否添加核密度曲线',
                            choices = c('否', '是')),
                pickerInput(
                  inputId = "view_hist_1_color",
                  label = "选择绘图的颜色", 
                  choices = c("black","white","green","pink","yellow","red","blue","orange"),
                  options = list(
                    style = "btn-primary")),
                sliderInput(inputId = "view_hist_1_bins",
                            label = "binwidth",
                            min = 1,
                            max = 50,
                            value = 30),
                actionButton("view_hist_1_applynewname", "应用")
      ),
      wellPanel( id = 'view_hist_2',
                 plotOutput('view_hist_2_plot'),
                 actionButton('view_hist_2_control', label = '调节图形的整体外观'),
                 actionButton('view_hist_2_line', label = '添加曲线')
      ),
      wellPanel( id = 'view_hist_line',
                 uiOutput("view_hist_line_x"),
                 uiOutput("view_hist_line_y"),
                 actionButton("view_hist_line_applynewname", "应用")
      ),
      widget_ui(view_hist, 'view_hist_3', 'hist_x_breaks', 'hist_y_breaks', 'hist_theme', 'hist_grid', 'hist_title'),
      wellPanel(id = 'view_box_1',
                uiOutput("view_box_1_selectx"),
                uiOutput("view_box_1_selecty"),
                uiOutput("view_box_1_selectg"),
                textInput(inputId = 'view_box_1_title', label = '输入标题名称'),
                actionButton("view_box_1_applynewname", "应用"),
      ),
      wellPanel( id = 'view_box_2',
                 plotOutput('view_box_2_plot'),
      ),
      wellPanel(id = 'view_par_1',
                uiOutput("view_par_1_selectx"),
                uiOutput("view_par_1_selectt"),
                uiOutput("view_par_1_selectty"),
                textInput(inputId = 'view_par_1_title', label = '输入标题名称'),
                actionButton("view_par_1_applynewname", "应用"),
      ),
      wellPanel( id = 'view_par_2',
                 plotOutput('view_par_2_plot'),
      ),
      wellPanel(id = 'view_radar_1',
                numericRangeInput(inputId = 'view_radar_1_xrange',
                                  label = '如果需要，请输入作图的行数起点与终点',
                                  value = c(1, 1000),
                                  separator = '至'),
                numericInput(inputId = 'view_radar_1_xseq',
                             label = '如果需要，请输入行数数列公差',
                             value = 1),
                textInput(inputId = 'view_radar_1_xextral', label = '如果需要，请输入剩余的行数(例：1 4 2 8 5 7)', value = 0),
                uiOutput("view_radar_1_selecty"),
                textInput(inputId = 'view_radar_1_title', label = '输入标题名称'),
                actionButton("view_radar_1_applynewname", "应用"),
      ),
      wellPanel( id = 'view_radar_2',
                 textOutput('view_radar_2_error'),
                 plotOutput('view_radar_2_plot'),
      ),
      wellPanel(id = 'view_roc_1',
                uiOutput('view_roc_1_selectt'),
                uiOutput("view_roc_1_selectp"),
                textInput(inputId = 'view_roc_1_title', label = '输入标题名称'),
                actionButton("view_roc_1_applynewname", "应用"),
                
      ),
      wellPanel( id = 'view_roc_1_hide',
                 selectInput(inputId = 'view_roc_1_hide_select',
                             label = '选择图形风格(仅在绘制一条ROC曲线时可用)',
                             choices = c('Normal AUC','Partical AUC', 'Confidence intervals'))
                 
      ),
      wellPanel( id = 'view_roc_2',
                 textOutput('view_roc_2_error'),
                 verbatimTextOutput('view_roc_2_tab'),
                 textOutput('view_roc_2_txt'),
                 plotOutput('view_roc_2_plot'),
      ),
      wellPanel(id = 'view_wordcloud_1',
                uiOutput("view_wordcloud_1_select_word"),
                uiOutput("view_wordcloud_1_select_count"),
                selectInput(inputId = 'view_wordcloud_1_shape',
                            label = '请选择词云形状',
                            choices = c('circle', 'cardioid', 'diamond', 'triangle-forward', 'pentagon', 'star')),
                # textInput(inputId = 'view_wordcloud_1_input_shape', label = '自定义词云形状(例：A, R, S)', value = '无'),
                numericInput(inputId = 'view_wordcloud_1_size',
                             label = '前请输入词云的尺寸',
                             value = 1),
                actionButton("view_wordcloud_1_applynewname", "应用"),
      ),
      wellPanel( id = 'view_wordcloud_2',
                 wordcloud2Output('view_wordcloud_2_plot', width = '100%'),
      ),
      
      wellPanel(id = 'method_PCA_1',
                 uiOutput("method_PCA_1_selectx"),
                 actionButton("method_PCA_1_applySuishitu", "应用",width="100%"),
                 plotOutput("method_PCA_Suishitu"),
                 numericInput(inputId = "method_PCA_1_selectn",
                             label = "选择主成分数量",
                             #width = '100%',
                             value = NULL
                 ),
                 selectInput(inputId = 'method_PCA_1_selectmethod',
                             label = '选择旋转方法',
                             choices = c("无","最大方差法","四次幂级大法","最优斜交法","直接斜交法","等量最大法"),
                 ),
                 verbatimTextOutput('method_PCA_1_resultmain'),  
                 verbatimTextOutput('method_PCA_1_resultscore'),  
      ),
      
      wellPanel(id = 'method_EFA_1',
                uiOutput("method_EFA_1_selectx"),
                actionButton("method_EFA_1_applySuishitu", "应用",width="100%"),
                plotOutput("method_EFA_Suishitu"),
                numericInput(inputId = "method_EFA_1_selectn",
                             label = "选择因子数量",
                             #width = '100%',
                             value = NULL
                ),   
                selectInput(inputId = 'method_EFA_1_selectmethod',
                            label = '选择旋转方法',
                            choices = c("无","最大方差法","四次幂级大法","最优斜交法","直接斜交法","等量最大法"),
                ),
                verbatimTextOutput('method_EFA_1_resultmain'),  
                verbatimTextOutput('method_EFA_1_resultscore'),  
                plotOutput('method_EFA_1_resultpicture')
      ),
      
      wellPanel(id = 'method_glm_1',
                uiOutput('method_glm_1_selecty'),
                uiOutput('method_glm_1_selectx'),
                selectInput(inputId = 'method_glm_1_selectmethod',
                            label = '选择模型',
                            choices = c("Normal(identity)","binomial(logit)","Gamma(inverse)","poisson(log)"),
                ),
                actionButton(inputId = "method_glm_1_apply", label = "分析",width = '100%',class = "btn btn-warning btn"),),
      wellPanel(id = 'method_glm_2',
                verbatimTextOutput("method_glm_2_result"),
                plotOutput("method_glm_2_picture")
      ),
      wellPanel(id = 'method_cluster_1',
                selectInput(inputId = 'method_cluster_1_1',
                            label = '选择聚类方法',
                            choices = c("K-means","K-Medoids","系谱聚类","密度聚类")),
                uiOutput('method_cluster_1_name'),
                uiOutput('method_cluster_1_x'),
                numericInput(inputId = "method_cluster_1_selectn",
                             label = "选择分为几类",
                             #width = '100%',
                             value = 3
                ),   
               ),
      wellPanel(id = 'method_cluster_2', #k-means
                textOutput('method_cluster_2_text1'),
                verbatimTextOutput('method_cluster_2_resultext1'),
                textOutput('method_cluster_2_text2'),
                verbatimTextOutput('method_cluster_2_resultext2'),
                uiOutput("method_cluster_2_x"),
                uiOutput("method_cluster_2_y"),
                plotOutput("method_cluster_2_plot"),
      ),
      wellPanel(id = 'method_cluster_3', #k-medoids
                textOutput('method_cluster_3_text1'),
                verbatimTextOutput('method_cluster_3_resultext1'),      
                textOutput('method_cluster_3_text2'),
                verbatimTextOutput('method_cluster_3_resultext2'),
                plotOutput('method_cluster_3_plot')
      ),
      wellPanel(id = 'method_cluster_4', #系谱聚类
                plotOutput('method_cluster_4_plot'),
                textOutput('method_cluster_4_text1'),
                verbatimTextOutput('method_cluster_4_resultext1'),    
      ),
      wellPanel(id = 'method_cluster_5', #密度聚类
                numericInput(inputId = "method_cluster_5_eps",
                             label = "输入eps",
                             #width = '100%',
                             value = 0.5
                ), 
                numericInput(inputId = "method_cluster_5_MinPts",
                             label = "输入Minpts",
                             #width = '100%',
                             value = 5
                ),
                textOutput('method_cluster_5_text1'),
                verbatimTextOutput('method_cluster_5_resultext1'),    
                plotOutput("method_cluster_5_plotglobal"),
                uiOutput('method_cluster_5_selectx'),
                uiOutput('method_cluster_5_selecty'),
                plotOutput('method_cluster_5_plotsingle')
      ),
      
      )#对应mainpanel的括号
     
    ),

    
    )
    
  )



      
