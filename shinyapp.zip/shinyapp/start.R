
library(shiny)
runApp(".")
