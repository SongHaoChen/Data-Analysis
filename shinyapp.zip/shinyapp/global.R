fmin <- function(x){
  return(min(x, na.rm = T))
}

fmax <- function(x){
  return(max(x, na.rm = T))
}

fsd <- function(x){
  return(sd(x, na.rm = T))
}

fmedian <- function(x){
  return(median(x, na.rm = T))
}


fmean <- function(x){
  return(mean(x, na.rm = T))
}

