options(shiny.maxRequestSize = 30*1024^2)
# options(encoding = 'UTF-8')

# Define server logic required to draw a histogram
function(input, output) {
  
  #全局变量
  values <- reactiveValues(
    data = NULL,
    p = NULL,
    a = 0
  )
  
  output$tab_ds <- renderUI({
    #选择功能栏按钮
    radioGroupButtons(
      inputId = "method_1",
      label = "",
      choices = c("标题处理", "数据分组","重复值处理","异常值处理","生成变量"),
      individual = TRUE,
      status = "danger"
      #      checkIcon = list(
      #        yes = tags$i(class = "fa fa-circle", 
      #                     style = "color: steelblue"),
      #        no = tags$i(class = "fa fa-circle-o", 
      #                    style = "color: steelblue"))
    )
  })
  
  output$tab_view <- renderUI({
    #选择功能栏按钮
    radioGroupButtons(
      inputId = "method_2",
      label = "",
      choices = c('散点图','直方图',"箱线图","饼图","雷达图", 'ROC曲线','词云'),
      individual = TRUE,
      status = "danger"
      #      checkIcon = list(
      #        yes = tags$i(class = "fa fa-circle", 
      #                     style = "color: steelblue"),
      #        no = tags$i(class = "fa fa-circle-o", 
      #                    style = "color: steelblue"))
    )
  })
  
  output$tab_method <- renderUI({
    #选择功能栏按钮
    radioGroupButtons(
      inputId = "method_3",
      label = "",
      choices = c("描述","相关性","线性回归","广义线性回归","聚类分析","主成分分析","因子分析"),
      individual = TRUE,
      status = "danger"
      #      checkIcon = list(
      #        yes = tags$i(class = "fa fa-circle", 
      #                     style = "color: steelblue"),
      #        no = tags$i(class = "fa fa-circle-o", 
      #                    style = "color: steelblue"))
    )
  })  
  
  
  observeEvent(paste(input$tabset),{
    shinyjs::hide(id = "savesuccess")
    shinyjs::hide(id = 'ds_title_1')
    shinyjs::hide(id = 'ds_title_2')
    shinyjs::hide(id =  "ds_title_3")
    shinyjs::hide(id = 'ds_repeating_1')
    shinyjs::hide(id = 'ds_coding_1')
    shinyjs::hide(id = 'ds_coding_2')
    shinyjs::hide(id = 'ds_exceptonValues_1')
    shinyjs::hide(id = 'ds_variable_1')
    shinyjs::hide(id = 'ds_variable_2')
    shinyjs::hide(id = 'ds_variable_3')
    shinyjs::hide(id = 'view_scatter_1')
    shinyjs::hide(id = 'view_scatter_2')
    shinyjs::hide(id = 'view_scatter_3')
    shinyjs::hide(id = 'view_hist_1')
    shinyjs::hide(id = 'view_hist_2')
    shinyjs::hide(id = 'view_hist_3')
    shinyjs::hide(id = 'view_hist_line')
    shinyjs::hide(id = 'view_box_1')
    shinyjs::hide(id = 'view_box_2')
    shinyjs::hide(id = 'view_par_1')
    shinyjs::hide(id = 'view_par_2')
    shinyjs::hide(id = 'view_radar_1')
    shinyjs::hide(id = 'view_radar_2')
    shinyjs::hide(id = 'view_roc_1')
    shinyjs::hide(id = 'view_roc_1_hide')
    shinyjs::hide(id = 'view_roc_2')
    shinyjs::hide(id = 'view_wordcloud_1')
    shinyjs::hide(id = 'view_wordcloud_2')
    shinyjs::hide(id = 'method_discribe_1')
    shinyjs::hide(id = 'method_discribe_2')
    shinyjs::hide(id = 'method_cor_1')
    shinyjs::hide(id = 'method_cor_2')
    shinyjs::hide(id = 'method_cor_3')
    shinyjs::hide(id = 'method_regression_1')
    shinyjs::hide(id = 'method_regression_2')
    shinyjs::hide(id = 'method_glm_1')
    shinyjs::hide(id = 'method_glm_2')
    shinyjs::hide(id = 'method_PCA_1') 
    shinyjs::hide(id = 'method_EFA_1')
    shinyjs::hide(id = 'method_cluster_1')
    shinyjs::hide(id = 'method_cluster_2')
    shinyjs::hide(id = 'method_cluster_3')
    shinyjs::hide(id = 'method_cluster_4')
    shinyjs::hide(id = 'method_cluster_5')


  })
  
  
  observeEvent(input$method_1,{
    shinyjs::hide(id = "savesuccess")
    shinyjs::hide(id = 'ds_title_1')
    shinyjs::hide(id = 'ds_title_2')
    shinyjs::hide(id =  "ds_title_3")
    shinyjs::hide(id = 'ds_repeating_1')
    shinyjs::hide(id = 'ds_coding_1')
    shinyjs::hide(id = 'ds_coding_2')
    shinyjs::hide(id = 'ds_exceptonValues_1')
    shinyjs::hide(id = 'ds_variable_1')
    shinyjs::hide(id = 'ds_variable_2')
    shinyjs::hide(id = 'ds_variable_3')
    shinyjs::hide(id = 'view_scatter_1')
    shinyjs::hide(id = 'view_scatter_2')
    shinyjs::hide(id = 'view_scatter_3')
    shinyjs::hide(id = 'view_hist_1')
    shinyjs::hide(id = 'view_hist_2')
    shinyjs::hide(id = 'view_hist_3')
    shinyjs::hide(id = 'view_hist_line')
    shinyjs::hide(id = 'view_box_1')
    shinyjs::hide(id = 'view_box_2')
    shinyjs::hide(id = 'view_par_1')
    shinyjs::hide(id = 'view_par_2')
    shinyjs::hide(id = 'view_radar_1')
    shinyjs::hide(id = 'view_radar_2')
    shinyjs::hide(id = 'view_roc_1')
    shinyjs::hide(id = 'view_roc_1_hide')
    shinyjs::hide(id = 'view_roc_2')
    shinyjs::hide(id = 'view_wordcloud_1')
    shinyjs::hide(id = 'view_wordcloud_2')
    shinyjs::hide(id = 'method_discribe_1')
    shinyjs::hide(id = 'method_discribe_2')
    shinyjs::hide(id = 'method_cor_1')
    shinyjs::hide(id = 'method_cor_2')
    shinyjs::hide(id = 'method_cor_3')
    shinyjs::hide(id = 'method_regression_1')
    shinyjs::hide(id = 'method_regression_2') 
    shinyjs::hide(id = 'method_glm_1')
    shinyjs::hide(id = 'method_glm_2')
    shinyjs::hide(id = 'method_PCA_1') 
    shinyjs::hide(id = 'method_EFA_1')
    shinyjs::hide(id = 'method_cluster_1')
    shinyjs::hide(id = 'method_cluster_2')
    shinyjs::hide(id = 'method_cluster_3')
    shinyjs::hide(id = 'method_cluster_4')
    shinyjs::hide(id = 'method_cluster_5')
    if (input$method_1 == '标题处理'){
      shinyjs::show(id = 'ds_title_1')
      shinyjs::show(id = 'ds_title_2')
    }
    if (input$method_1 == '重复值处理'){
      shinyjs::show(id = 'ds_repeating_1')
    } 
    if (input$method_1 == '数据分组'){
      shinyjs::show(id = 'ds_coding_1')
      shinyjs::show(id = 'ds_coding_2')
    } 
    if (input$method_1 == '异常值处理'){
      shinyjs::show(id = 'ds_exceptonValues_1')
    }
    if(input$method_1 == '生成变量'){
      shinyjs::show(id = 'ds_variable_1')
      shinyjs::show(id = 'ds_variable_2')
    }

  })
  
  
  observeEvent(input$method_2,{
    shinyjs::hide(id = "savesuccess")
    shinyjs::hide(id = 'ds_title_1')
    shinyjs::hide(id = 'ds_title_2')
    shinyjs::hide(id =  "ds_title_3")
    shinyjs::hide(id = 'ds_repeating_1')
    shinyjs::hide(id = 'ds_coding_1')
    shinyjs::hide(id = 'ds_coding_2')
    shinyjs::hide(id = 'ds_exceptonValues_1')
    shinyjs::hide(id = 'ds_variable_1')
    shinyjs::hide(id = 'ds_variable_2')
    shinyjs::hide(id = 'ds_variable_3')
    shinyjs::hide(id = 'view_scatter_1')
    shinyjs::hide(id = 'view_scatter_2')
    shinyjs::hide(id = 'view_scatter_3')
    shinyjs::hide(id = 'view_hist_1')
    shinyjs::hide(id = 'view_hist_2')
    shinyjs::hide(id = 'view_hist_3')
    shinyjs::hide(id = 'view_hist_line')
    shinyjs::hide(id = 'view_box_1')
    shinyjs::hide(id = 'view_box_2')
    shinyjs::hide(id = 'view_par_1')
    shinyjs::hide(id = 'view_par_2')
    shinyjs::hide(id = 'view_radar_1')
    shinyjs::hide(id = 'view_radar_2')
    shinyjs::hide(id = 'view_roc_1')
    shinyjs::hide(id = 'view_roc_1_hide')
    shinyjs::hide(id = 'view_roc_2')
    shinyjs::hide(id = 'view_wordcloud_1')
    shinyjs::hide(id = 'view_wordcloud_2')
    shinyjs::hide(id = 'method_discribe_1')
    shinyjs::hide(id = 'method_discribe_2')
    shinyjs::hide(id = 'method_cor_1')
    shinyjs::hide(id = 'method_cor_2')
    shinyjs::hide(id = 'method_cor_3')
    shinyjs::hide(id = 'method_regression_1')
    shinyjs::hide(id = 'method_regression_2') 
    shinyjs::hide(id = 'method_glm_1')
    shinyjs::hide(id = 'method_glm_2')
    shinyjs::hide(id = 'method_PCA_1') 
    shinyjs::hide(id = 'method_EFA_1')
    shinyjs::hide(id = 'method_cluster_1')
    shinyjs::hide(id = 'method_cluster_2')
    shinyjs::hide(id = 'method_cluster_3')
    shinyjs::hide(id = 'method_cluster_4')
    shinyjs::hide(id = 'method_cluster_5')
    if(input$method_2 == '散点图'){
      shinyjs::show(id = 'view_scatter_1')
      shinyjs::show(id = 'view_scatter_2')
      #shinyjs::show(id = 'view_scatter_3')
    }
    if(input$method_2 == '直方图'){
      shinyjs::show(id = 'view_hist_1')
      shinyjs::show(id = 'view_hist_2')
    }
    if(input$method_2 == '箱线图'){
      shinyjs::show(id = 'view_box_1')
      shinyjs::show(id = 'view_box_2')
    }
    if(input$method_2 == '饼图'){
      shinyjs::show(id = 'view_par_1')
      shinyjs::show(id = 'view_par_2')
    }
    if(input$method_2 == '雷达图'){
      shinyjs::show(id = 'view_radar_1')
      shinyjs::show(id = 'view_radar_2')
    }
    if(input$method_2 == 'ROC曲线'){
      shinyjs::show(id = 'view_roc_1')
      shinyjs::show(id = 'view_roc_1_hide')
      shinyjs::show(id = 'view_roc_2')
    }
    if(input$method_2 == '词云'){
      shinyjs::show(id = 'view_wordcloud_1')
      shinyjs::show(id = 'view_wordcloud_2')
    }
  })
  
  observeEvent(input$method_3,{
    shinyjs::hide(id = "savesuccess")
    shinyjs::hide(id = 'ds_title_1')
    shinyjs::hide(id = 'ds_title_2')
    shinyjs::hide(id =  "ds_title_3")
    shinyjs::hide(id = 'ds_repeating_1')
    shinyjs::hide(id = 'ds_coding_1')
    shinyjs::hide(id = 'ds_coding_2')
    shinyjs::hide(id = 'ds_exceptonValues_1')
    shinyjs::hide(id = 'ds_variable_1')
    shinyjs::hide(id = 'ds_variable_2')
    shinyjs::hide(id = 'ds_variable_3')
    shinyjs::hide(id = 'view_scatter_1')
    shinyjs::hide(id = 'view_scatter_2')
    shinyjs::hide(id = 'view_scatter_3')
    shinyjs::hide(id = 'view_hist_1')
    shinyjs::hide(id = 'view_hist_2')
    shinyjs::hide(id = 'view_hist_3')
    shinyjs::hide(id = 'view_hist_line')
    shinyjs::hide(id = 'view_box_1')
    shinyjs::hide(id = 'view_box_2')
    shinyjs::hide(id = 'view_par_1')
    shinyjs::hide(id = 'view_par_2')
    shinyjs::hide(id = 'view_radar_1')
    shinyjs::hide(id = 'view_radar_2')
    shinyjs::hide(id = 'view_roc_1')
    shinyjs::hide(id = 'view_roc_1_hide')
    shinyjs::hide(id = 'view_roc_2')
    shinyjs::hide(id = 'view_wordcloud_1')
    shinyjs::hide(id = 'view_wordcloud_2')
    shinyjs::hide(id = 'method_discribe_1')
    shinyjs::hide(id = 'method_discribe_2')
    shinyjs::hide(id = 'method_cor_1')
    shinyjs::hide(id = 'method_cor_2')
    shinyjs::hide(id = 'method_cor_3')
    shinyjs::hide(id = 'method_regression_1')
    shinyjs::hide(id = 'method_regression_2') 
    shinyjs::hide(id = 'method_glm_1')
    shinyjs::hide(id = 'method_glm_2')
    shinyjs::hide(id = 'method_PCA_1') 
    shinyjs::hide(id = 'method_EFA_1')
    shinyjs::hide(id = 'method_cluster_1')
    shinyjs::hide(id = 'method_cluster_2')
    shinyjs::hide(id = 'method_cluster_3')
    shinyjs::hide(id = 'method_cluster_4')
    shinyjs::hide(id = 'method_cluster_5')
    
    if (input$method_3 == '描述'){
      shinyjs::show(id = 'method_discribe_1')
      shinyjs::show(id = 'method_discribe_2')
    }
    
    if (input$method_3 == '相关性'){
      shinyjs::show(id = 'method_cor_1')
      shinyjs::show(id = 'method_cor_2')
      shinyjs::show(id = 'method_cor_3')
    }
    
    if (input$method_3 == '线性回归'){
      shinyjs::show(id = 'method_regression_1')
      shinyjs::show(id = 'method_regression_2')
    }
    
    if (input$method_3 == "广义线性回归"){
      shinyjs::show(id = 'method_glm_1')
      shinyjs::show(id = 'method_glm_2')
    }
    
    if (input$method_3 == '主成分分析'){
      shinyjs::show(id = 'method_PCA_1')
    }
    
    if (input$method_3 == '因子分析'){
      shinyjs::show(id = 'method_EFA_1')
    }
    
    if (input$method_3 == "聚类分析"){
      shinyjs::show(id = 'method_cluster_1')
      if (input$method_cluster_1_1 == "K-means") shinyjs::show(id = 'method_cluster_2')
      if (input$method_cluster_1_1 == "K-Medoids") shinyjs::show(id = 'method_cluster_3')
      if (input$method_cluster_1_1 == "系谱聚类") shinyjs::show(id = 'method_cluster_4')
      if (input$method_cluster_1_1 == "密度聚类") shinyjs::show(id = 'method_cluster_5')
    }
  }) 
  
  observeEvent(input$method_cluster_1_1,{
    shinyjs::hide(id = 'method_cluster_2')
    shinyjs::hide(id = 'method_cluster_3')
    shinyjs::hide(id = 'method_cluster_4')
    shinyjs::hide(id = 'method_cluster_5')
    if (input$method_cluster_1_1 == "K-means"){
      shinyjs::show(id = 'method_cluster_2')
      shinyjs::show(id = 'method_cluster_1_selectn')
    }
    if (input$method_cluster_1_1 == "K-Medoids") {
      shinyjs::show(id = 'method_cluster_3')
      shinyjs::show(id = 'method_cluster_1_selectn')
    }
    if (input$method_cluster_1_1 == "系谱聚类"){
      shinyjs::show(id = 'method_cluster_4')
      shinyjs::hide(id = 'method_cluster_1_selectn')
    }
    if (input$method_cluster_1_1 == "密度聚类"){
      shinyjs::show(id = 'method_cluster_5')
      shinyjs::hide(id = 'method_cluster_1_selectn')
    }
  })
  
  observeEvent(input$view_scatter_2_control,{
    if(input$view_scatter_2_control %%2 == 1)
      shinyjs::show(id = 'view_scatter_3')
    else
      shinyjs::hide(id = 'view_scatter_3')
  })
  
  observeEvent(input$view_hist_2_control,{
    if(input$view_hist_2_control %%2 == 1)
      shinyjs::show(id = 'view_hist_3')
    else
      shinyjs::hide(id = 'view_hist_3')
  })
  
  observeEvent(input$view_hist_2_line,{
    if(input$view_hist_2_line %%2 == 1)
      shinyjs::show(id = 'view_hist_line')
    else
      shinyjs::hide(id = 'view_hist_line')
  })
  
  observeEvent(input$ds_variable_2_hlevel,{
    if(input$ds_variable_2_hlevel %%2 == 1)
      shinyjs::show(id = 'ds_variable_3')
    else
      shinyjs::hide(id = 'ds_variable_3')
  })
  
  observeEvent(input$file1,{
    req(input$file1)
    values$data<-read.csv(input$file1$datapath)
    shinyjs::hide(id = 'ds_repeating_1_cancel')
 })

  
#标题处理begin
  observeEvent(input$ds_title_2_applynewname,{
               if (input$ds_title_2_newname %in% names(values$data)){shinyjs::show(id = "ds_title_3")}
                    else{
                      names(values$data)[which(input$ds_title_2_1 == names(values$data))]<-input$ds_title_2_newname
                      shinyjs::hide(id = "ds_title_3")
                      }

  }
  )
  
  ds_title_2_newname <- eventReactive(input$ds_title_2_applynewname,{
    return(input$ds_title_2_newname)
  })

  outputdata <- reactive({
    return(values$data)
  })
  
  output$ds_title_1_showname <- renderTable({
     names(values$data)
  })
  
  output$ds_title_2_select <- renderUI({
    
    pickerInput(
      inputId = "ds_title_2_1",
      label = "选择需要重命名的变量", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$ds_title_1_showdata <-renderTable({
    head(values$data)
  })
#标题处理end

#数据分组begin
  
  observeEvent(input$ds_coding_2_applynewname,{
    if(length(input$ds_coding_2_1) != 0){
      if(input$ds_coding_2_method == '2groups_median'){
        # assign(paste0(input$ds_coding_2_1, '_2groups_median'), values$data[input$ds_coding_2_1])
        
        group_med <- 0
        group_med[which(values$data[input$ds_coding_2_1] < median(as.vector(unlist(values$data[input$ds_coding_2_1]))) ) ] <- 1
        group_med[which(values$data[input$ds_coding_2_1] >= median(as.vector(unlist(values$data[input$ds_coding_2_1]))) ) ] <- 2
        values$data[paste0(input$ds_coding_2_1, '_2groups_median')] = group_med
      }else if(input$ds_coding_2_method == '2groups_mean'){
        group_mea <- 0
        group_mea[which(values$data[input$ds_coding_2_1] < mean(as.vector(unlist(values$data[input$ds_coding_2_1]))) ) ] <- 1
        group_mea[which(values$data[input$ds_coding_2_1] >= mean(as.vector(unlist(values$data[input$ds_coding_2_1]))) ) ] <- 2
        values$data[paste0(input$ds_coding_2_1, '_2groups_mean')] = group_mea
      }else if(input$ds_coding_2_method == '3groups_median'){
        group_mea3 <- 0
        quan_num <- quantile(as.vector(unlist(values$data[input$ds_coding_2_1])), c(0.33, 0.67), na.rm = TRUE)
        group_mea3[which(values$data[input$ds_coding_2_1] < as.numeric(quan_num)[1] ) ] <- 1
        group_mea3[which(values$data[input$ds_coding_2_1] < as.numeric(quan_num)[2] & values$data[input$ds_coding_2_1] >= as.numeric(quan_num)[1]) ] <- 2
        group_mea3[which(values$data[input$ds_coding_2_1] >= as.numeric(quan_num)[2] ) ] <- 3
        values$data[paste0(input$ds_coding_2_1, '_3groups_median')] = group_mea3
      } else if(input$ds_coding_2_method == '4groups_median'){
        group_mea4 <- 1
        quan_num <- quantile(as.vector(unlist(values$data[input$ds_coding_2_1])), c(0.25, 0.5, 0.75), na.rm = TRUE)
        group_mea4[which(values$data[input$ds_coding_2_1] < as.numeric(quan_num)[1] ) ] <- 1
        group_mea4[which(values$data[input$ds_coding_2_1] < as.numeric(quan_num)[2] & values$data[input$ds_coding_2_1] >= as.numeric(quan_num)[1]) ] <- 2
        group_mea4[which(values$data[input$ds_coding_2_1] < as.numeric(quan_num)[3] & values$data[input$ds_coding_2_1] >= as.numeric(quan_num)[2]) ] <- 3
        group_mea4[which(values$data[input$ds_coding_2_1] >= as.numeric(quan_num)[3] ) ] <- 4
        values$data[paste0(input$ds_coding_2_1, '_4groups_median')] = group_mea4
      } 
      
    }
  })
  output$ds_coding_1_showname <- renderTable({
    names(values$data)
  })
  
  output$ds_coding_2_select <- renderUI({
    
    pickerInput(
      inputId = "ds_coding_2_1",
      label = "选择需要分组的变量", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  output$ds_coding_1_out <- renderTable({
    head(values$data)
  })
#数据分组end
  
  
#重复值处理begin
  
  observeEvent(input$ds_repeating_1_applydelete,{
    if (TRUE %in% duplicated(values$data)) write.csv(values$data, 'data_repeating.csv', row.names = FALSE)
    values$data <- values$data[!duplicated(values$data),]    
    shinyjs::show(id = 'ds_repeating_1_cancel')
  })
  
  observeEvent(input$ds_repeating_1_cancel,{
     values$data <- read.csv('data_repeating.csv')
  })
  
  output$ds_repeating_1_describe <- renderText({
    if (TRUE %in% duplicated(values$data)) "多余（重复）的行:"
  })
  
  
  output$ds_repeating_1_show <- renderTable({
    if (TRUE %in% duplicated(values$data))
      values$data[duplicated(values$data),]
    else return("无重复值")
  })
  
#重复值处理end  
 
  
#异常值处理begin
  output$ds_exceptonValues_1_select <- renderUI({
    pickerInput(
      inputId = "ds_exceptonValues_1_1",
      label = "选择进行异常值处理的变量", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  observeEvent(input$ds_exceptonValues_1_apply,{
    mu <- mean(values$data[,input$ds_exceptonValues_1_1], na.rm = TRUE)
    sd <- sd(values$data[,input$ds_exceptonValues_1_1], na.rm = TRUE)
    median <- median(values$data[,input$ds_exceptonValues_1_1], na.rm = TRUE)
    duo <- names(which.max(table(values$data[,input$ds_exceptonValues_1_1])))
    op <- 0
    if (input$ds_exceptonValues_1_lack == TRUE){
       opt <- is.na(values$data[,input$ds_exceptonValues_1_1])
       opt[is.na(opt)] <- FALSE
       op <- op | opt
    }
    if (input$ds_exceptonValues_1_greater == TRUE){
      opt <- (values$data[,input$ds_exceptonValues_1_1] > input$ds_exceptonValues_1_greater_number)
      opt[is.na(opt)] <- FALSE
      op <- op | opt
    }
    if (input$ds_exceptonValues_1_less == TRUE){
      opt <- (values$data[,input$ds_exceptonValues_1_1] < input$ds_exceptonValues_1_less_number)
      opt[is.na(opt)] <- FALSE
      op <- op | opt
    } 
    if (input$ds_exceptonValues_1_offcenter == TRUE){
      opt <- (abs(values$data[,input$ds_exceptonValues_1_1] - mu) > input$ds_exceptonValues_1_offcenter_number * sd)
      opt[is.na(opt)] <- FALSE
      op <- op | opt
    }
    
    
    if (input$ds_exceptonValues_1_2 == "NA")
      values$data[op, input$ds_exceptonValues_1_1] <- NA
    if (input$ds_exceptonValues_1_2 == "平均值")
      values$data[op, input$ds_exceptonValues_1_1] <- mu
    if (input$ds_exceptonValues_1_2 == "中位数")
      values$data[op, input$ds_exceptonValues_1_1] <- median
    if (input$ds_exceptonValues_1_2 == "众数")
      values$data[op, input$ds_exceptonValues_1_1] <- duo
    if (input$ds_exceptonValues_1_2 == "0")
      values$data[op, input$ds_exceptonValues_1_1] <- 0
  })
  

  #异常值处理end
  #生成变量begin
  
  output$ds_variable_1_showname <- renderTable({
    names(values$data)
  })
  
  output$ds_variable_2_select <- renderUI({
    pickerInput(
      inputId = "ds_variable_2_1",
      label = "选择变量", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$ds_variable_1_out <- renderTable({
    head(values$data)
  })
  
  observeEvent(input$ds_variable_2_applynewname,{
    if(length(input$ds_variable_2_1) != 0){
      if(input$ds_variable_2_method == '标准化(S)'){
        var_s <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_s <- (var_s - mean(var_s)) / sd(var_s)
        values$data[paste0('S_',input$ds_variable_2_1)] = var_s
      }else 
      if(input$ds_variable_2_method == '中心化(C)'){
        var_c <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_c <- var_c - mean(var_c)
        values$data[paste0('C_',input$ds_variable_2_1)] = var_c
      }else 
      if(input$ds_variable_2_method == '归一化(MMS)'){
        var_mms <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_mms <- (var_mms - min(var_mms)) / (max(var_mms) - min(var_mms))
        values$data[paste0('MMS_',input$ds_variable_2_1)] = var_mms
      }else 
      if(input$ds_variable_2_method == '均值化(MC)'){
        var_mc <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_mc <- (var_mc) / mean(var_mc)
        values$data[paste0('MC_',input$ds_variable_2_1)] = var_mc
      }else 
      if(input$ds_variable_2_method == '逆向化(NMMS)'){
        var_nmms <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_nmms <- (max(var_nmms)-var_nmms ) / ( max(var_nmms) - min(var_nmms))
        values$data[paste0('NMMS_',input$ds_variable_2_1)] = var_nmms
      }else 
      if(input$ds_variable_2_method == '区间化(Interval)'){
        var_interval <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_interval <- 1 + (2-1) * (var_interval-min(var_interval)) / (max(var_interval) - min(var_interval))
        values$data[paste0('Interval_',input$ds_variable_2_1)] = var_interval
      }else 
        if(input$ds_variable_2_method == '初值化(Init)'){
        var_init <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        #var_init <- var_init / var_init[-is.na(var_init)][1]
        var_init <- var_init / var_init[1]
        values$data[paste0('Init_',input$ds_variable_2_1)] = var_init
      }else 
        if(input$ds_variable_2_method == '求和归一化(SN)'){
        var_sn <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_sn <- var_sn / sum(var_sn)
        values$data[paste0('Sn_',input$ds_variable_2_1)] = var_sn
      }else 
        if(input$ds_variable_2_method == '平方和归一化(SSN)'){
        var_ssn <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_ssn <- var_ssn / sqrt(sum(var_ssn^2))
        values$data[paste0('SSn_',input$ds_variable_2_1)] = var_ssn
      }else 
        if(input$ds_variable_2_method == '倒数(cb)'){
        var_cb <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_cb <- 1 / var_cb
        values$data[paste0('Cb_',input$ds_variable_2_1)] = var_cb
      }else 
        if(input$ds_variable_2_method == '自然对数(Ln)'){
        var_ln <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_ln <- log(var_ln)
        values$data[paste0('Ln_',input$ds_variable_2_1)] = var_ln
      }else 
        if(input$ds_variable_2_method == '10底对数(Log)'){
        var_log <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_log <- log(var_log, 10)
        values$data[paste0('Log_',input$ds_variable_2_1)] = var_log
      }else 
        if(input$ds_variable_2_method == '平方(Sq)'){
        var_sq <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_sq <- var_sq ^ 2
        values$data[paste0('Sq_',input$ds_variable_2_1)] = var_sq
      }else 
        if(input$ds_variable_2_method == '立方(Cube)'){
        var_cube <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_cube <- var_cube ^ 3
        values$data[paste0('Cube_',input$ds_variable_2_1)] = var_cube
      }else 
        if(input$ds_variable_2_method == '相反数(Op)'){
        var_op <- as.vector(unlist(values$data[input$ds_variable_2_1])) 
        var_op <- -1 * var_op
        values$data[paste0('Op_',input$ds_variable_2_1)] = var_op
      }
    }
  })
  
  output$ds_variable_select_var1 <- renderUI({
    pickerInput(
      inputId = "ds_variable_3_1",
      label = "选择var1", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$ds_variable_select_var2 <- renderUI({
    pickerInput(
      inputId = "ds_variable_3_2",
      label = "选择var2", 
      choices = c('无', names(values$data)),
      options = list(
        style = "btn-primary")
    )
  })
  
  observeEvent(input$ds_variable_3_applynewname,{
    var1 <- as.vector(unlist(values$data[input$ds_variable_3_1]))
    if(input$ds_variable_3_2 != '无'){
      var2 <- as.vector(unlist(values$data[input$ds_variable_3_2]))
      express <- eval(parse(text = input$ds_variable_3_text))
      values$data[paste0(input$ds_variable_3_text,'~',input$ds_variable_3_1, '&',input$ds_variable_3_2)] = express}
    else{
      express <- eval(parse(text = input$ds_variable_3_text))
      values$data[paste0(input$ds_variable_3_text,'~',input$ds_variable_3_1)]= express}
  })
#生成变量end
  

#通用方法  
#描述begin
    output$method_discribe_1_select <- renderUI({
    multiInput(
      inputId = "method_discribe_1_1",
      label = "选择进行描述的变量", 
      choices = names(values$data),
      choiceNames = lapply(seq_along(names(values$data)), 
                           function(i) tagList(names(values$data)[i])),
      choiceValues = names(values$data)
    )
  })
  
  observeEvent(input$method_describe_1_apply,{
    output$method_discribe_2_result <- renderTable({
      data<-values$data[input$method_discribe_1_1]
      na2 <- !is.na(data)
      number <- apply(na2, 2, sum)
      number <- data.frame(number)
      min <- apply(data, 2, fmin)
      min <- data.frame(min)
      max <- apply(data, 2, fmax)
      max <- data.frame(max)
      mean <- apply(data, 2, fmean)
      mean <- data.frame(mean)
      sd <- apply(data, 2, fsd)
      sd <- data.frame(sd)
      median <- apply(data, 2, fmedian)
      median <- data.frame(median)
      r <- cbind(number, min ,max, mean, sd, median)
      colnames(r) <- c("样本量", "最小值", "最大值", "平均值", "标准差", "中位数")
      r2 <- names(data)
      r2 <- data.frame(r2)
      names(r2) <- " "
      r3 <- cbind(r2, r)
      r3
    })
  })
#描述end
  
#相关性begin
  output$method_cor_1_select <- renderUI({
    multiInput(
      inputId = "method_cor_1_1",
      label = "选择进行分析的变量", 
      choices = names(values$data),
      choiceNames = lapply(seq_along(names(values$data)), 
                           function(i) tagList(names(values$data)[i])),
      choiceValues = names(values$data)
    )
  })
  observeEvent(input$method_cor_1_apply,{ 
    output$method_cor_2_matrix <- renderTable({
      data<-values$data[input$method_cor_1_1]
      rcov <- cor(data)
      r1 <- names(data)
      r1 <- data.frame(r1)
      names(r1) <- " "
      mean <- apply(data, 2, fmean)
      mean <- data.frame(mean)
      names(mean) <- "平均值"
      sd <- apply(data, 2, fsd)
      sd <- data.frame(sd)
      names(sd) <- "标准差"
      r <- cbind(r1, mean, sd, rcov)
    })
  })
  observeEvent(input$method_cor_1_apply,{
    output$method_cor_3_pic <- renderPlot({
      data<-values$data[input$method_cor_1_1]
      r <- cor(data)
      melted_r <- melt(r)
      pic <- ggplot(data = melted_r, aes(x=Var1, y=Var2, fill=value)) + geom_tile(color='white')+scale_fill_gradient(low=input$method_cor_3_low,high=input$method_cor_3_high)
      pic
    })
  })
#相关性end

#线性回归begin
  output$method_regression_1_selecty <- renderUI({
    pickerInput(
      inputId = "method_regression_1_1",
      label = "选择因变量", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })

  output$method_regression_1_selectx <- renderUI({
    multiInput(
      inputId = "method_regression_1_2",
      label = "选择自变量", 
      choices = names(values$data),
      choiceNames = lapply(seq_along(names(values$data)), 
                           function(i) tagList(names(values$data)[i])),
      choiceValues = names(values$data)
    )
  })
  
  observeEvent(input$method_regression_1_apply,{
    output$method_regression_2_result <- renderPrint({
      datay <- values$data[input$method_regression_1_1]
      datax <- values$data[input$method_regression_1_2]
      data <- cbind(datax, datay)
      formulay <- input$method_regression_1_1
      formulax <- input$method_regression_1_2
      fx <- paste(formulax[], collapse = '+')
      formula <- paste(formulay, fx, sep = '~')
      fit <- lm(formula = formula, data = data)
      summary(fit)
    })  
  })
  
  observeEvent(input$method_regression_1_apply,{
  output$method_regression_2_picture <- renderPlot({
    if (length(input$method_regression_1_2) == 1) {
    datay <- values$data[input$method_regression_1_1]
    datax <- values$data[input$method_regression_1_2]
    data <- cbind(datax, datay)
    formulay <- input$method_regression_1_1
    formulax <- input$method_regression_1_2
    fx <- paste(formulax[], collapse = '+')
    formula <- paste(formulay, fx, sep = '~')
    fit <- lm(formula = formula, data = data)
    pic <- ggplot() + geom_line(data = data, aes(unlist(datax), fitted(fit))) + geom_point(data = data, aes(unlist(datax),unlist(datay)))
    pic <- pic + xlab(input$method_regression_1_2) + ylab(input$method_regression_1_1)
    pic
    }
  })})
  #线性回归end
  
  #散点图begin
  output$view_scatter_1_selectx <- renderUI({
    pickerInput(
      inputId = "view_scatter_1_x",
      label = "选择变量x", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$view_scatter_1_selecty <- renderUI({
    pickerInput(
      inputId = "view_scatter_1_y",
      label = "选择变量y", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$view_scatter_1_selectg <- renderUI({
    pickerInput(
      inputId = "view_scatter_1_g",
      label = "选择分组变量", 
      choices = c('无', names(values$data)),
      options = list(
        style = "btn-primary")
    )
  })
  
  observeEvent(input$view_scatter_1_applynewname,{
    temp_data <- values$data
    names(temp_data)[which(input$view_scatter_1_x == names(temp_data))] <- 'x'
    names(temp_data)[which(input$view_scatter_1_y == names(temp_data))] <- 'y'
    names(temp_data)[which(input$view_scatter_1_g == names(temp_data))] <- 'g'
    output$view_scatter_2_plot <- renderPlot({
      p <-  ggplot(temp_data, aes(y = y, x = x)) 
        # geom_point(aes(color = g))  +
      if (input$view_scatter_1_g != '无') {
        p <-  p + geom_point(aes(color = g))  
        #return(p1)
      }else{p <- p + geom_point()}
      if (input$scatter_x_breaks != '默认'){
        breaks <- as.numeric(unlist(strsplit(input$scatter_x_breaks, ' ')))
        p <- p + scale_x_continuous(breaks = breaks)
      }
      if (input$scatter_y_breaks != '默认'){
        breaks <- as.numeric(unlist(strsplit(input$scatter_y_breaks, ' ')))
        p <- p + scale_y_continuous(breaks = breaks)
      }
      if(input$scatter_theme == 'theme_light') 
        p <- p + theme_light() 
      if(input$scatter_theme == 'theme_dark') 
        p <- p + theme_dark() 
      p <- p + labs(title = input$scatter_title)
      if(input$scatter_grid == '隐藏纵轴网格线'){
        p <- p +theme(panel.grid.major.x = element_blank(), panel.grid.minor.x = element_blank())
      }
      if(input$scatter_grid == '隐藏横轴网格线'){
        p <- p +theme(panel.grid.major.y = element_blank(), panel.grid.minor.y = element_blank())
      }
      if(input$scatter_grid == '隐藏所有网格线'){
        p <- p +theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())
      }
      return(p)
      #quoted = TRUE
    })    
  })
  
  #散点图 end
  
  #柱状图 begin
  
  output$view_hist_1_selectx <- renderUI({
    pickerInput(
      inputId = "view_hist_1_x",
      label = "选择变量", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$view_hist_1_selectg <- renderUI({
    pickerInput(
      inputId = "view_hist_1_g",
      label = "选择分组变量", 
      choices = c('无', names(values$data)),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$view_hist_line_x <- renderUI({
    pickerInput(
      inputId = "view_hist_line_1",
      label = "选择x轴数据", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$view_hist_line_y <- renderUI({
    pickerInput(
      inputId = "view_hist_line_2",
      label = "选择y轴数据", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  observeEvent(input$view_hist_1_applynewname,{
    binwid <- input$view_hist_1_bins 
    temp_data <- values$data
    names(temp_data)[which(input$view_hist_1_x == names(temp_data))] <- 'x'
    names(temp_data)[which(input$view_hist_1_g == names(temp_data))] <- 'g'
    output$view_hist_2_plot <- renderPlot({
      p <-  ggplot(temp_data, aes(x = x)) 
      if (input$view_hist_1_g != '无') {
        if(input$view_hist_1_type == '频数分布直方图'){
        p <- p + geom_histogram(aes(fill = temp_data$g), binwidth = binwid)
        }else{
          p <- p + geom_histogram(aes(y = ..density.., fill = temp_data$g), binwidth = binwid)
        }
      }else{
        if(input$view_hist_1_type == '频数分布直方图'){
          p <- p + geom_histogram(binwidth = binwid, fill = input$view_hist_1_color)
      }else{
        p <- p + geom_histogram(aes(y = ..density..), binwidth = binwid, fill = input$view_hist_1_color)}
        }
          
      if (input$view_hist_1_line == '是') p <- p + stat_density(geom = 'line')
      #p <- p + labs(title = input$view_hist_1_title)
      # 整体外观
      if (input$hist_x_breaks != '默认'){
        breaks <- as.numeric(unlist(strsplit(input$hist_x_breaks, ' ')))
        p <- p + scale_x_continuous(breaks = breaks)
      }
      if (input$hist_y_breaks != '默认'){
        breaks <- as.numeric(unlist(strsplit(input$hist_y_breaks, ' ')))
        p <- p + scale_y_continuous(breaks = breaks)
      }
      if(input$hist_theme == 'theme_light') 
        p <- p + theme_light() 
      if(input$hist_theme == 'theme_dark') 
        p <- p + theme_dark() 
      p <- p + labs(title = input$hist_title)
      if(input$hist_grid == '隐藏纵轴网格线'){
        p <- p +theme(panel.grid.major.x = element_blank(), panel.grid.minor.x = element_blank())
      }
      if(input$hist_grid == '隐藏横轴网格线'){
        p <- p +theme(panel.grid.major.y = element_blank(), panel.grid.minor.y = element_blank())
      }
      if(input$hist_grid == '隐藏所有网格线'){
        p <- p +theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())
      }
      return(p)
      })    
  })
  
  observeEvent(input$view_hist_line_applynewname, {
    binwid <- input$view_hist_1_bins 
    temp_data <- values$data
    names(temp_data)[which(input$view_hist_1_x == names(temp_data))] <- 'x'
    names(temp_data)[which(input$view_hist_1_g == names(temp_data))] <- 'g'
    output$view_hist_2_plot <- renderPlot({
      p <-  ggplot(temp_data, aes(x = x)) 
      if (input$view_hist_1_g != '无') {
        if(input$view_hist_1_type == '频数分布直方图'){
          p <- p + geom_histogram(aes(fill = temp_data$g), binwidth = binwid)
        }else{
          p <- p + geom_histogram(aes(y = ..density.., fill = temp_data$g), binwidth = binwid)
        }
      }else{
        if(input$view_hist_1_type == '频数分布直方图'){
          p <- p + geom_histogram(binwidth = binwid, fill = input$view_hist_1_color)
        }else{
          p <- p + geom_histogram(aes(y = ..density..), binwidth = binwid, fill = input$view_hist_1_color)}
      }
      
      if (input$view_hist_1_line == '是') p <- p + stat_density(geom = 'line')
      #p <- p + labs(title = input$view_hist_1_title)
      # 整体外观
      if (input$hist_x_breaks != '默认'){
        breaks <- as.numeric(unlist(strsplit(input$hist_x_breaks, ' ')))
        p <- p + scale_x_continuous(breaks = breaks)
      }
      if (input$hist_y_breaks != '默认'){
        breaks <- as.numeric(unlist(strsplit(input$hist_y_breaks, ' ')))
        p <- p + scale_y_continuous(breaks = breaks)
      }
      if(input$hist_theme == 'theme_light') 
        p <- p + theme_light() 
      if(input$hist_theme == 'theme_dark') 
        p <- p + theme_dark() 
      p <- p + labs(title = input$hist_title)
      if(input$hist_grid == '隐藏纵轴网格线'){
        p <- p +theme(panel.grid.major.x = element_blank(), panel.grid.minor.x = element_blank())
      }
      if(input$hist_grid == '隐藏横轴网格线'){
        p <- p +theme(panel.grid.major.y = element_blank(), panel.grid.minor.y = element_blank())
      }
      if(input$hist_grid == '隐藏所有网格线'){
        p <- p +theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())
      }
      temp_data2 <- values$data
      names(temp_data2)[which(input$view_hist_line_1 == names(temp_data2))] <- 'x'
      names(temp_data2)[which(input$view_hist_line_2 == names(temp_data2))] <- 'y'
      p <- p + geom_line(data = temp_data2, aes(x = x, y = y))
      return(p)
    })  
      })
  
  
  # 柱状图end
  
  # 盒图begin
  
  output$view_box_1_selectx <- renderUI({
    pickerInput(
      inputId = "view_box_1_x",
      label = "选择变量", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$view_box_1_selecty <- renderUI({
    pickerInput(
      inputId = "view_box_1_y",
      label = "选择分组变量", 
      choices =  c('无', names(values$data)),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$view_box_1_selectg <- renderUI({
    pickerInput(
      inputId = "view_box_1_g",
      label = "选择着色变量", 
      choices = c('无', names(values$data)),
      options = list(
        style = "btn-primary")
    )
  })
  
  observeEvent(input$view_box_1_applynewname,{
    temp_data <- values$data
    names(temp_data)[which(input$view_box_1_x == names(temp_data))] <- 'x'
    names(temp_data)[which(input$view_box_1_y == names(temp_data))] <- 'y'
    names(temp_data)[which(input$view_box_1_g == names(temp_data))] <- 'g'
    output$view_box_2_plot <- renderPlot({
      p <-  ggplot(temp_data) 
      if (input$view_box_1_y != '无' & input$view_box_1_g != '无') {
        p <-  ggplot(temp_data) 
        p <- p + geom_boxplot(aes(x = y, y = x, fill = factor(g)))
      }else if(input$view_box_1_y != '无' & input$view_box_1_g == '无'){
        p <- p + geom_boxplot(aes(x = y, y = x, group = y))
      }else if(input$view_box_1_y == '无' & input$view_box_1_g != '无'){
        p <- p + geom_boxplot(aes(y = x, fill = factor(g)))
      }else if(input$view_box_1_y == '无' & input$view_box_1_g == '无'){
        p <- p + geom_boxplot(aes(y = x))
      }
      p <- p + labs(title = input$view_box_1_title)
      return(p)
    })
  })
  
  # 盒图 end
  # 饼图 begin
  
  output$view_par_1_selectx <- renderUI({
    pickerInput(
      inputId = "view_par_1_x",
      label = "选择变量", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$view_par_1_selectt <- renderUI({
    pickerInput(
      inputId = "view_par_1_t",
      label = "选择标签", 
      choices =  c('无', names(values$data)),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$view_par_1_selectty <- renderUI({
    pickerInput(
      inputId = "view_par_1_ty",
      label = "选择图形类型", 
      choices = c('常规饼图', '环图'),
      options = list(
        style = "btn-primary")
    )
  })
  
  observeEvent(input$view_par_1_applynewname,{
    temp_data <- values$data
    names(temp_data)[which(input$view_par_1_x == names(temp_data))] <- 'x'
    names(temp_data)[which(input$view_par_1_t == names(temp_data))] <- 't'
    output$view_par_2_plot <- renderPlot({
      if(input$view_par_1_ty == '常规饼图'){
        temp_data = temp_data[order(temp_data$x, decreasing = TRUE),]
        myLabel = as.vector(temp_data$t)   
        myLabel = paste(myLabel, "(", round(temp_data$x / sum(temp_data$x) * 100, 2), "%)", sep = "")   
        p = ggplot(temp_data, aes(x = "", y = x, fill = t)) +
          geom_bar(stat = "identity", width = 1) +    
          coord_polar(theta = "y") + 
          labs(x = "", y = "", title = "") + 
          theme(axis.ticks = element_blank()) + 
          theme(legend.title = element_blank(), legend.position = "top") + 
          scale_fill_discrete(breaks = temp_data$t, labels = myLabel) + 
          theme(axis.text.x = element_blank()) 
        # geom_text(aes(y = x/2 + c(0, cumsum(x)[-length(x)]), x = sum(x)/20, label = myLabel), size = 5) 
      }else if(input$view_par_1_ty == '环图'){
        rate <- as.vector(unlist(temp_data$x))
        coutry <- as.vector(unlist(temp_data$t))
        rate_per<-paste(as.character(round(rate / sum(rate), 2)),'%',sep='')
        ad<-data.frame(type=coutry,n=rate,rate_per=rate_per)
        ad$fraction = ad$n / sum(ad$n)
        ad$ymax = cumsum(ad$fraction)
        ad$ymin = c(0, head(ad$ymax, n = -1))
        p<-ggplot(data = ad, aes(fill = type, ymax = ymax, ymin = ymin, xmax = 4, xmin = 3)) +
          geom_rect(show.legend = F,alpha=0.8) +
          scale_fill_brewer(palette = 'Set3')+
          coord_polar(theta = "y") +
          labs(x = "", y = "", title = "",fill='地区') + 
          xlim(c(0, 5)) +
          theme_light() +
          theme(panel.grid=element_blank()) + ## 去掉白色外框
          theme(axis.text=element_blank()) + ## 把图旁边的标签去掉
          theme(axis.ticks=element_blank()) + ## 去掉左上角的坐标刻度线
          theme(panel.border=element_blank()) + ## 去掉最外层的正方形边框
          geom_text(aes(x = 4.6, y = ((ymin+ymax)/2),label = type) ,size=4)+
          geom_text(aes(x = 3.5, y = ((ymin+ymax)/2),label = rate_per) ,size=3.6)
      }
      p <- p + labs(title = input$view_par_1_title)
      return(p)
    })
  })
  
  # 饼图 end
  # 雷达图 begin
  output$view_radar_1_selecty <- renderUI({
    multiInput(
      inputId = "view_radar_1_selecty_1",
      label = "请选择需要作图的变量集,所选第一个变量自动视为标签", 
      choices = names(values$data),
      choiceNames = lapply(seq_along(names(values$data)), 
                           function(i) tagList(names(values$data)[i])),
      choiceValues = names(values$data)
    )
  })
  
  observeEvent(input$view_radar_1_applynewname,{
    temp_data <- values$data[input$view_radar_1_selecty_1]
    
    if (input$view_radar_1_xrange[2] > length(temp_data[ ,1])){
      output$view_radar_2_error <- renderText({
        return('输入行数超过数据最大值')
      })
    }else{
      if(input$view_radar_1_xrange[1] < input$view_radar_1_xrange[2] ){
        row1 <- seq(input$view_radar_1_xrange[1], input$view_radar_1_xrange[2], input$view_radar_1_xseq)}
      else{row1 <- NULL}
      row2 <- as.numeric(unlist(strsplit(input$view_radar_1_xextral, ' ')))
      if (row2 == 0) temp_row <- row1
      else temp_row <- c(row1, row2)
      output$view_radar_2_plot <- renderPlot({
        ggradar(temp_data[temp_row, ]) +
          labs(title = input$view_radar_1_title)
      })
      output$view_radar_2_error <- renderText({
        return('')
      })
    }
  })
  
  # 雷达图 end
  
  # ROC曲线 begin
  output$view_roc_1_selectt <- renderUI({
    pickerInput(
      inputId = "view_roc_1_1",
      label = "选择真值", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$view_roc_1_selectp <- renderUI({
    multiInput(
      inputId = "view_roc_1_2",
      label = "选择预测值", 
      choices = names(values$data),
      choiceNames = lapply(seq_along(names(values$data)), 
                           function(i) tagList(names(values$data)[i])),
      choiceValues = names(values$data)
    )
  })
  
  
  
  #observeEvent(output$view_roc_1_selectp,{
  #if (length(input$view_roc_1_2) == 1)
  #  shinyjs::show(id = 'view_roc_1_hide')
  #else
  #shinyjs::hide(id = 'view_roc_1_hide')
  # })
  
  observeEvent(input$view_roc_1_applynewname,{
    if (input$view_roc_1_1 %in% input$view_roc_1_2){
      output$view_roc_2_error <- renderText({
        #cat(red('错误：预测值中包含了真值，请重新选择。'))
        print('错误：预测值中包含了真值，请重新选择。')
      })
      
      output$view_roc_2_tab <- renderPrint({})
      output$view_roc_2_txt <- renderText({})
      
    }
    else{
      
      
      output$view_roc_2_error <- renderText({
        return('     样本分析')
      })
      
      temp_data <- values$data
      temp_data2 <- temp_data
      names(temp_data2)[which(input$view_roc_1_1 == names(temp_data))] <- 'Truth'
      names(temp_data2)[which(input$view_roc_1_2 == names(temp_data))] <- 'Predictions'
      c1 <- as.vector(unlist(temp_data2$Truth))
      
      output$view_roc_2_tab <- renderPrint({
        l1 <- c(sum(c1), length(c1)-sum(c1), sum(c1))
        l2 <- c(paste0(round(sum(c1)/length(c1) * 100, 2), '%'), paste0(round(100 - sum(c1)/length(c1) * 100, 2), '%'), paste0('100','%'))
        df1 <- data.frame(l1, l2)
        dimnames(df1) <- list(c('阳性', '阴性', '总计'), c('频数', '百分比'))
        return(df1)
        #table(temp_data2$Truth, temp_data2$Predictions)
        #table(as.vector(unlist(temp_data[input$view_roc_1_1])), as.vector(unlist(temp_data[input$view_roc_1_2])))
      })
      
      output$view_roc_2_txt <- renderText({
        str1 <- paste('由上表可知,', '针对', list(input$view_roc_1_2),'构造ROC曲线,用于判断对于',input$view_roc_1_1, '的诊断价值。
                     从上表可以看出阳性的比例为：', paste0(round(sum(c1)/length(c1) * 100, 2), '%'), ',阴性的比例为：',
                     paste0(round(100 - sum(c1)/length(c1) * 100, 2), '%'), '。')
        return(str1)
      })
      
      if (length(input$view_roc_1_2) > 1){
        output$view_roc_2_plot <- renderPlot({
          plot.roc(as.vector(unlist(temp_data[input$view_roc_1_1])) ,  as.vector(unlist(temp_data[input$view_roc_1_2[1]])),
                   main = input$view_roc_1_title, percent = TRUE, col = '#1c61b6')
          for (i in 2:length(input$view_roc_1_2)){
            lines.roc(as.vector(unlist(temp_data[input$view_roc_1_1])) ,  as.vector(unlist(temp_data[input$view_roc_1_2[i]])),
                      main = input$view_roc_1_title, percent = TRUE)
          }
        })
      }else
        if(length(input$view_roc_1_2) == 1){
          
          output$view_roc_2_plot <- renderPlot({
            if(input$view_roc_1_hide_select == 'Normal AUC'){
              plot.roc(as.vector(unlist(temp_data[input$view_roc_1_1])) ,  as.vector(unlist(temp_data[input$view_roc_1_2])),
                       main = input$view_roc_1_title, percent = TRUE, col = '#1c61b6', print.auc = TRUE)
            }else
              if(input$view_roc_1_hide_select == 'Partical AUC'){
                plot.roc(as.vector(unlist(temp_data[input$view_roc_1_1])), as.vector(unlist(temp_data[input$view_roc_1_2])), # data
                         percent=TRUE, # show all values in percent
                         partial.auc=c(100, 90), partial.auc.correct=TRUE, # define a partial AUC (pAUC)
                         print.auc=TRUE, #display pAUC value on the plot with following options:
                         print.auc.pattern="Corrected pAUC (100-90%% SP):\n%.1f%%", print.auc.col="#1c61b6",
                         auc.polygon=TRUE, auc.polygon.col="#1c61b6", # show pAUC as a polygon
                         max.auc.polygon=TRUE, max.auc.polygon.col="#1c61b622", # also show the 100% polygon
                         main=input$view_roc_1_title)
                plot.roc(as.vector(unlist(temp_data[input$view_roc_1_1])), as.vector(unlist(temp_data[input$view_roc_1_2])),
                         percent=TRUE, add=TRUE, type="n", # add to plot, but don't re-add the ROC itself (useless)
                         partial.auc=c(100, 90), partial.auc.correct=TRUE,
                         partial.auc.focus="se", # focus pAUC on the sensitivity
                         print.auc=TRUE, print.auc.pattern="Corrected pAUC (100-90%% SE):\n%.1f%%", print.auc.col="#008600",
                         print.auc.y=40, # do not print auc over the previous one
                         auc.polygon=TRUE, auc.polygon.col="#008600",
                         max.auc.polygon=TRUE, max.auc.polygon.col="#00860022")
              }else
                if(input$view_roc_1_hide_select == 'Confidence intervals'){
                  rocobj <- plot.roc(as.vector(unlist(temp_data[input$view_roc_1_1])), as.vector(unlist(temp_data[input$view_roc_1_2])),
                                     main=input$view_roc_1_title, percent=TRUE,
                                     ci=TRUE, # compute AUC (of AUC by default)
                                     print.auc=TRUE) # print the AUC (will contain the CI)
                  ciobj <- ci.se(rocobj, # CI of sensitivity
                                 specificities=seq(0, 100, 5)) # over a select set of specificities
                  plot(ciobj, type="shape", col="#1c61b6AA") # plot as a blue shape
                  plot(ci(rocobj, of="thresholds", thresholds="best")) # add one threshold
                }
            
          })
        }}
    
  })
  #ROC曲线end
  #wordcloud begin
  
  output$view_wordcloud_1_select_word <- renderUI({
    pickerInput(
      inputId = "view_wordcloud_1_1",
      label = "选择词组", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$view_wordcloud_1_select_count <- renderUI({
    pickerInput(
      inputId = "view_wordcloud_1_2",
      label = "选择词频", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  observeEvent(input$view_wordcloud_1_applynewname,{
    temp_data <- values$data
    names(temp_data)[which(input$view_wordcloud_1_1 == names(temp_data))] <- 'word'
    names(temp_data)[which(input$view_wordcloud_1_2 == names(temp_data))] <- 'count'
    temp_data <- data.frame(word = temp_data$word, count = temp_data$count)
    output$view_wordcloud_2_plot <- renderWordcloud2({
      p <- wordcloud2(data = temp_data, size = input$view_wordcloud_1_size, shape = input$view_wordcloud_1_shape)
      return(p)
    })
  })
  
  
  
  
  
  
  
  
  
  
  
  #PCA begin
  output$method_PCA_1_selectx <- renderUI({
    multiInput(
      inputId = "method_PCA_1_1",
      label = "选择进行主成分提取的变量", 
      choices = names(values$data),
      choiceNames = lapply(seq_along(names(values$data)), 
                           function(i) tagList(names(values$data)[i])),
      choiceValues = names(values$data)
    )
  })
  
  observeEvent(input$method_PCA_1_applySuishitu,
    output$method_PCA_Suishitu <- renderPlot({
        fa.parallel(cor(values$data[input$method_PCA_1_1]),fa='pc',n.iter = 100,show.legend = F,main = 'Scree plot with parallel analysis')
    })
  )
  
  output$method_PCA_1_resultmain <- renderPrint({
    if (input$method_PCA_1_selectmethod == "无") rotate <- "none"
    if (input$method_PCA_1_selectmethod == "最大方差法") rotate <- "varimax"
    if (input$method_PCA_1_selectmethod == "四次幂级大法") rotate <- "quartimax"
    if (input$method_PCA_1_selectmethod == "最优斜交法") rotate <- "promax"
    if (input$method_PCA_1_selectmethod == "直接斜交法") rotate <- "oblimin"
    if (input$method_PCA_1_selectmethod == "等量最大法") rotate <- "simplimax"
    pc <-  principal(cor(values$data[input$method_PCA_1_1]),nfactors = input$method_PCA_1_selectn,rotate = rotate)
    pc
  })
  
  output$method_PCA_1_resultscore <- renderPrint({
    if (input$method_PCA_1_selectmethod == "无") rotate <- "none"
    if (input$method_PCA_1_selectmethod == "最大方差法") rotate <- "varimax"
    if (input$method_PCA_1_selectmethod == "四次幂级大法") rotate <- "quartimax"
    if (input$method_PCA_1_selectmethod == "最优斜交法") rotate <- "promax"
    if (input$method_PCA_1_selectmethod == "直接斜交法") rotate <- "oblimin"
    if (input$method_PCA_1_selectmethod == "等量最大法") rotate <- "simplimax"
    pc <-  principal(cor(values$data[input$method_PCA_1_1]),nfactors = input$method_PCA_1_selectn,rotate = rotate, scores=TRUE)
    round(unclass(pc$weights),input$method_PCA_1_selectn)
  })
  #PCA end
  
  #EFA begin
  output$method_EFA_1_selectx <- renderUI({
    multiInput(
      inputId = "method_EFA_1_1",
      label = "选择进行主成分提取的变量", 
      choices = names(values$data),
      choiceNames = lapply(seq_along(names(values$data)), 
                           function(i) tagList(names(values$data)[i])),
      choiceValues = names(values$data)
    )
  })
  
  observeEvent(input$method_EFA_1_applySuishitu,
               output$method_EFA_Suishitu <- renderPlot({
                 fa.parallel(cor(values$data[input$method_EFA_1_1]),fa='both',n.iter = 100,show.legend = F,main = 'Scree plot with parallel analysis')
               })
  )
  
  output$method_EFA_1_resultmain <- renderPrint({
    if (input$method_EFA_1_selectmethod == "无") rotate <- "none"
    if (input$method_EFA_1_selectmethod == "最大方差法") rotate <- "varimax"
    if (input$method_EFA_1_selectmethod == "四次幂级大法") rotate <- "quartimax"
    if (input$method_EFA_1_selectmethod == "最优斜交法") rotate <- "promax"
    if (input$method_EFA_1_selectmethod == "直接斜交法") rotate <- "oblimin"
    if (input$method_EFA_1_selectmethod == "等量最大法") rotate <- "simplimax"
    fa <-  fa(cor(values$data[input$method_EFA_1_1]),nfactors = input$method_EFA_1_selectn,rotate = rotate)
    fa

  })
  
  output$method_EFA_1_resultscore <- renderPrint({
    if (input$method_EFA_1_selectmethod == "无") rotate <- "none"
    if (input$method_EFA_1_selectmethod == "最大方差法") rotate <- "varimax"
    if (input$method_EFA_1_selectmethod == "四次幂级大法") rotate <- "quartimax"
    if (input$method_EFA_1_selectmethod == "最优斜交法") rotate <- "promax"
    if (input$method_EFA_1_selectmethod == "直接斜交法") rotate <- "oblimin"
    if (input$method_EFA_1_selectmethod == "等量最大法") rotate <- "simplimax"
    fa <-  fa(cor(values$data[input$method_EFA_1_1]),nfactors = input$method_EFA_1_selectn,rotate = rotate, scores = TRUE)
    round(unclass(fa$weights),input$method_EFA_1_selectn)

  })
  
  output$method_EFA_1_resultpicture <- renderPlot({
    if (input$method_EFA_1_selectmethod == "无") rotate <- "none"
    if (input$method_EFA_1_selectmethod == "最大方差法") rotate <- "varimax"
    if (input$method_EFA_1_selectmethod == "四次幂级大法") rotate <- "quartimax"
    if (input$method_EFA_1_selectmethod == "最优斜交法") rotate <- "promax"
    if (input$method_EFA_1_selectmethod == "直接斜交法") rotate <- "oblimin"
    if (input$method_EFA_1_selectmethod == "等量最大法") rotate <- "simplimax"
    fa <-  fa(cor(values$data[input$method_EFA_1_1]),nfactors = input$method_EFA_1_selectn,rotate = rotate, score = TRUE)
    fa.diagram(fa,simple=FALSE)
  })
  
  #EFA end
  
#glm begin
  output$method_glm_1_selecty <- renderUI({
    pickerInput(
      inputId = "method_glm_1_1",
      label = "选择因变量", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$method_glm_1_selectx <- renderUI({
    multiInput(
      inputId = "method_glm_1_2",
      label = "选择自变量", 
      choices = names(values$data),
      choiceNames = lapply(seq_along(names(values$data)), 
                           function(i) tagList(names(values$data)[i])),
      choiceValues = names(values$data)
    )
  })
  
  observeEvent(input$method_glm_1_apply,{
    output$method_glm_2_result <- renderPrint({
      datay <- values$data[input$method_glm_1_1]
      datax <- values$data[input$method_glm_1_2]
      data <- cbind(datax, datay)
      formulay <- input$method_glm_1_1
      formulax <- input$method_glm_1_2
      fx <- paste(formulax[], collapse = '+')
      formula <- paste(formulay, fx, sep = '~')
      if (input$method_glm_1_selectmethod == "Normal(identity)") family <- gaussian(link = "identity")
      if (input$method_glm_1_selectmethod == "binomial(logit)") family <- binomial(link = "logit")
      if (input$method_glm_1_selectmethod == "Gamma(inverse)") family <- Gamma(link = "inverse")
      if (input$method_glm_1_selectmethod == "poisson(log)") family <- poisson(link = "log")
      fit <- glm(formula = formula, data = data, family = family)
      summary(fit)
    })  
  })
  
  observeEvent(input$method_glm_1_apply,{
    output$method_glm_2_picture <- renderPlot({
      datay <- values$data[input$method_glm_1_1]
      datax <- values$data[input$method_glm_1_2]
      data <- cbind(datax, datay)
      formulay <- input$method_glm_1_1
      formulax <- input$method_glm_1_2
      fx <- paste(formulax[], collapse = '+')
      formula <- paste(formulay, fx, sep = '~')
      if (input$method_glm_1_selectmethod == "Normal(identity)") family <- gaussian(link = "identity")
      if (input$method_glm_1_selectmethod == "binomial(logit)") family <- binomial(link = "logit")
      if (input$method_glm_1_selectmethod == "Gamma(inverse)") family <- Gamma(link = "inverse")
      if (input$method_glm_1_selectmethod == "poisson(log)") family <- poisson(link = "log")
      fit <- glm(formula = formula, data = data, family = family)
      pic <- ggplot() + geom_line(data = data, aes(unlist(datax), fitted(fit)))
      pic <- pic + xlab(input$method_glm_1_2) + ylab(input$method_glm_1_1) + geom_point(data = data, aes(unlist(datax),unlist(datay)))
      pic
    })  
  })
#glm end

#聚类begin
  
  output$method_cluster_1_name <- renderUI({
    pickerInput(
      inputId = "method_cluster_1_2",
      label = "选择名称", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$method_cluster_1_x <- renderUI({
    multiInput(
      inputId = "method_cluster_1_3",
      label = "选择进行分类的特征", 
      choices = names(values$data),
      choiceNames = lapply(seq_along(names(values$data)), 
                           function(i) tagList(names(values$data)[i])),
      choiceValues = names(values$data)
    )
  })
  
  output$method_cluster_2_text1 <- renderText({
    "分类结果"
  })

  output$method_cluster_2_resultext1 <- renderPrint({
    r <- kmeans(values$data[input$method_cluster_1_3],input$method_cluster_1_selectn)
    table(as.vector(unlist(values$data[input$method_cluster_1_2])), r$cluster)
  })
  
  output$method_cluster_2_text2 <- renderText({
    "具体描述"
  })
  
  output$method_cluster_2_resultext2 <- renderPrint({
    r <- kmeans(values$data[input$method_cluster_1_3],input$method_cluster_1_selectn)
    r
  })
  

  
  output$method_cluster_2_x <- renderUI({
    pickerInput(
      inputId = "method_cluster_2_1",
      label = "选择x轴", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$method_cluster_2_y <- renderUI({
    pickerInput(
      inputId = "method_cluster_2_2",
      label = "选择y轴", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$method_cluster_2_plot <- renderPlot({
    r <- kmeans(values$data[input$method_cluster_1_3],input$method_cluster_1_selectn)
    plot(as.vector(unlist(values$data[input$method_cluster_2_1])),as.vector(unlist(values$data[input$method_cluster_2_2])), col=r$cluster,pch='*',xlab = input$method_cluster_2_1, ylab = input$method_cluster_2_2)
    points(r$centers,pch="X",cex=1.5,col=4)
  })
  
  
  
  
  output$method_cluster_3_text1 <- renderText({
    "分类结果"
  })
  
  output$method_cluster_3_resultext1 <- renderPrint({
    r <- pam(values$data[input$method_cluster_1_3],input$method_cluster_1_selectn)
    table(as.vector(unlist(values$data[input$method_cluster_1_2])), r$clustering)
  })
  
  output$method_cluster_3_text2 <- renderText({
    "具体描述"
  })
  
  output$method_cluster_3_resultext2 <- renderPrint({
    r <- pam(values$data[input$method_cluster_1_3],input$method_cluster_1_selectn)
    r
  })
  
  
  output$method_cluster_3_plot <- renderPlot({
    data <-values$data
    x <- data[input$method_cluster_1_3]
    k <- input$method_cluster_1_selectn
    r <- pam(x, k)
    layout(matrix(c(1,2),1,2))
    plot(r)
  })
  
  output$method_cluster_4_text1 <- renderText({
    "具体描述"
  })
  
  output$method_cluster_4_resultext1 <- renderPrint({
    r <- hclust(dist(values$data[input$method_cluster_1_3]))
    r[1:length(r)]
  })
  
  output$method_cluster_4_plot <- renderPlot({
    r <- hclust(dist(values$data[input$method_cluster_1_3]))
    plot(r)
  })
  
  output$method_cluster_5_plotglobal <- renderPlot({
    r <- dbscan(values$data[input$method_cluster_1_3],eps=input$method_cluster_5_eps,MinPts = input$method_cluster_5_MinPts)
    plot(r, values$data[input$method_cluster_1_3])
  })
  
  output$method_cluster_5_text1 <- renderText({
    "分类结果"
  })
  
  output$method_cluster_5_resultext1 <- renderPrint({
    r <- dbscan(values$data[input$method_cluster_1_3],eps=input$method_cluster_5_eps,MinPts = input$method_cluster_5_MinPts)
    table(r$cluster, as.vector(unlist(values$data[input$method_cluster_1_2])))
  })
  
  output$method_cluster_5_selectx <- renderUI({
    pickerInput(
      inputId = "method_cluster_5_1",
      label = "选择x轴", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  
  output$method_cluster_5_selecty <- renderUI({
    pickerInput(
      inputId = "method_cluster_5_2",
      label = "选择y轴", 
      choices = names(values$data),
      options = list(
        style = "btn-primary")
    )
  })
  
  output$method_cluster_5_plotsingle <- renderPlot({
    r <- dbscan(values$data[input$method_cluster_1_3],eps=input$method_cluster_5_eps,MinPts = input$method_cluster_5_MinPts)
    data <- values$data[input$method_cluster_1_3]
    plot(r, data[,c(input$method_cluster_5_1,input$method_cluster_5_2)])
  })
  
#聚类end
  
  observeEvent(input$save,{
    write.csv(values$data, paste("./savedata/",input$savename,".csv",sep=""),row.names=FALSE)
    shinyjs::show(id = "savesuccess")
  })
  
  output$savetext <- renderText({
    paste("已成功保存至",getwd(),"./savedata/",input$savename,".csv",sep="")
  })

  observeEvent(input$openUserManual,{
    shell.exec(".\\User manual\\User-manual.html")
  })
  observeEvent(input$openMulu,{
    shell.exec(".\\")
  })
  
  # save the tempdata every 1000ms * 60 * 1
  autoInvalidate <- reactiveTimer(1000 * 60 * 1)
  observe({
    autoInvalidate()
    a = a + 1
    d = Sys.Date()
    t = Sys.time()
    path = paste0(getwd(),'/tempdata/',
                  d,'-', substr(t, 12, 13), '-', substr(t, 15, 16), '-', substr(t, 18, 19), '.csv')
    write.csv(values$data, path,row.names=FALSE)
  })
  
}
